package com.byte_dance.example;

import android.os.Bundle;
import android.util.Log;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.RecognizerListener;
import com.iflytek.cloud.RecognizerResult;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechRecognizer;

/**
 * Created by Administrator on 2021/11/1.
 *
 * 讯飞语音工具类.
 */

public class RecognizerUtils {

    private static String TAG = RecognizerUtils.class.getSimpleName();

    // 构造初始化讯飞监听器相关.
    public static InitListener construct_initLister(){

        return new InitListener() {

            @Override
            public void onInit(int code) {
                Log.i(TAG, "SpeechRecognizer init() code = " + code);
                if (code != ErrorCode.SUCCESS) {
                    Log.i(TAG, "初始化失败，错误码：" + code + ",请点击网址https://www.xfyun.cn/document/error-code查询解决方案");
                }
            }
        };

    }

    // 构建监听器.
    public static RecognizerListener construct_RecognizerListener(){

        return new RecognizerListener() {
            @Override
            public void onVolumeChanged(int i, byte[] bytes) {
                Log.i(TAG, "当前正在说话，音量大小 = " + i + " 返回音频数据 = " + bytes.length);
            }

            @Override
            public void onBeginOfSpeech() {
                // 此回调表示：sdk内部录音机已经准备好了，用户可以开始语音输入
                Log.i(TAG, "开始说话");
            }

            @Override
            public void onEndOfSpeech() {
                // 此回调表示：检测到了语音的尾端点，已经进入识别过程，不再接受语音输入
                Log.i(TAG, "结束说话");
            }

            @Override
            public void onResult(RecognizerResult recognizerResult, boolean b) {
                Log.i(TAG, recognizerResult.getResultString());
                if (b){
                    Log.i(TAG, "onResult 结束");
                }
            }

            @Override
            public void onError(SpeechError speechError) {
                // 错误码：10118(您没有说话)，可能是录音机权限被禁，需要提示用户打开应用的录音权限.
                Log.i(TAG, "onError " + speechError.getPlainDescription(true));
            }

            @Override
            public void onEvent(int i, int i1, int i2, Bundle bundle) {

            }
        };
    }

    // 设置参数.
    public static SpeechRecognizer setParam(SpeechRecognizer mIat){
        // 清空参数.
        mIat.setParameter(SpeechConstant.CLOUD_GRAMMAR, null );
        mIat.setParameter(SpeechConstant.SUBJECT, null );

        // 设置返回结果格式.目前支持json,xml以及plain 三种格式，其中plain为纯听写文本内容.
        mIat.setParameter(SpeechConstant.RESULT_TYPE, "json");
        // 此处engineType为"Cloud"
        mIat.setParameter( SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
        // 设置语音输入语言.
        mIat.setParameter(SpeechConstant.LANGUAGE, "en_us");
        // 自动停止录音.

        return mIat;
    }
}
