package com.byte_dance.example;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechRecognizer;
import com.iflytek.cloud.SpeechUtility;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static String TAG = MainActivity.class.getSimpleName();

    // 讯飞相关.
    private SpeechRecognizer mIat;

    // 组件相关.
    private Button clickButton;
    private Toast mToast;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 讯飞注册.
        SpeechUtility.createUtility(this, SpeechConstant.APPID+"=1e699da7");
        mIat = SpeechRecognizer.createRecognizer(MainActivity.this, RecognizerUtils.construct_initLister());

        // 组件赋值.
        clickButton = (Button) findViewById(R.id.click_button);
        clickButton.setOnClickListener(MainActivity.this);
    }

    @Override
    public void onClick(View view){
        if (null == mIat){
            this.showTip("mIat is Null");
            return;
        }

        switch (view.getId()){
            case R.id.click_button:
                mIat = RecognizerUtils.setParam(mIat);
                mIat.startListening(RecognizerUtils.construct_RecognizerListener());
        }

    }

    private void showTip(final String str) {
        if (mToast != null) {
            mToast.cancel();
        }
        mToast = Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT);
        mToast.show();
    }
}
